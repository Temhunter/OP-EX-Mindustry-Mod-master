# OP-EX-Mod

My OverPowered Mindustry Mod

Description/Info: I took Anuke's example mod and removed a few items like the silver turret. I then edited most-to-all the files to make everything more overpowered and easier to obtain (everything in the mod is now free to craft). Some people would kind of see this like a cheat mod, idk it's your opinion. Maybe in the future I can edit other modder's mods if you want me to and/or just make modpacks for people (by combining multiple mods into 1 folder mod thing). Might add new things in a much later update if I feel like it.

Update V1.8 {The Mender Update}:

- Modded the mender (not tested)

- Updated to V1.8


Creator: Founder

Discord: HNU Founder.lua#5046
